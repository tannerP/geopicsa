/**
 * Created by tanner on 9/25/17.
 */
var DB = [
    {
        visible: false, park_name: "Jefferson Park", lat: 47.5700757, lng: -122.307825, city: "Seattle"
    },
    {
        visible: false, park_name: "Bennefits Park", lat: 47.5190676, lng: -122.284141299, city: "Seattle"
    },
    {
        visible: false, park_name: "Liberty Park", lat: 47.4819186, lng: -122.199315, city: "Renton"
    },
    {
        visible: false, park_name: "Greenlake Park", lat: 47.6802132, lng: -122.32831880000003, city: "Seattle"
    },
    {
        visible: false, park_name: "Delridge Park", lat:47.5610904, lng:-122.3635719, city: "Seattle"
    }
];
